
-- Run this in Supabase SQL Editor
CREATE TABLE IF NOT EXISTS replies (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  email text NOT NULL,
  reply text NOT NULL,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now())
);
