import React, { useState } from "react"
import axios from "axios"
import toast from "react-hot-toast"
import logo from "../assets/logo.png"
import { supabase } from "../lib/supabase"

const API_URL = import.meta.env.VITE_API_URL || "http://127.0.0.1:8000"

export function Home() {
  const [email, setEmail] = useState("")
  const [tone, setTone] = useState("empathetic")
  const [reply, setReply] = useState("")

  const downloadReply = () => {
        const blob = new Blob([reply], { type: 'text/plain' })
        const link = document.createElement('a')
        link.href = URL.createObjectURL(blob)
        link.download = 'reply.txt'
        link.click()
      }

  const handleGenerate = async () => {
const saveReply = async (email, reply) => {
        try {
          await supabase.from("replies").insert([{ email, reply }])
        } catch (err) {
          console.error("Supabase save error:", err)
        }
      }

    try {
      const res = await axios.post(`${API_URL}/generate-reply`, {
        rejection_email: email,
        tone: tone,
        user_id: "frontend-user"
      })
      setReply(res.data.reply)
      saveReply(email, res.data.reply)
      toast.success("Reply generated!")
    } catch (err) {
      toast.error("Failed to generate reply")
      console.error(err)
    }
  }

  return (
    <div className="max-w-3xl mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Rejection Reply Generator</h1>

      <label className="block mb-2 font-medium">Rejection Email</label>
      <textarea
        className="w-full h-32 p-2 border border-gray-300 rounded"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      ></textarea>

      <label className="block mt-4 mb-2 font-medium">Tone</label>
      <select
        className="w-full p-2 border border-gray-300 rounded"
        value={tone}
        onChange={(e) => setTone(e.target.value)}
      >
        <option value="empathetic">Empathetic</option>
        <option value="professional">Professional</option>
        <option value="optimistic">Optimistic</option>
      </select>

      <button
        onClick={handleGenerate}
        className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
      >
        Generate Reply
      </button>

      {reply && (
        <div className="mt-6 p-4 bg-gray-100 border border-gray-300 rounded">
          <h2 className="font-semibold mb-2">Generated Reply:</h2>
          <p>{reply}</p>
<button
          onClick={() => {
            navigator.clipboard.writeText(reply)
            toast.success("Copied to clipboard!")
          }}
        >Copy Reply</button>
        <button
          onClick={downloadReply}
          className="mt-2 ml-2 px-3 py-1 bg-gray-200 rounded hover:bg-gray-300"
        >
          Download .txt
        </button>
          className="mt-2 px-3 py-1 bg-gray-200 rounded hover:bg-gray-300"
        >
          Copy Reply
        </button>
        </div>
      )}
    </div>
  )
}