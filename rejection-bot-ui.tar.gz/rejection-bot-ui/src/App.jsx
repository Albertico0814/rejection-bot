import { useEffect, useState } from "react"
import { Home } from "./pages/Home"

function App() {
  const [theme, setTheme] = useState("dark")

  useEffect(() => {
    document.body.className = theme
  }, [theme])

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="absolute top-4 right-4">
        <button
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          className="text-sm px-3 py-1 rounded bg-slate-700 text-white hover:bg-slate-600 dark:bg-white dark:text-black dark:hover:bg-slate-200"
        >
          {theme === "dark" ? "Light Mode" : "Dark Mode"}
        </button>
      </div>
      <div className="w-full max-w-3xl rounded-2xl shadow-lg p-8 mt-12 bg-white text-black dark:bg-slate-800 dark:text-white">
        <Home />
      </div>
    </div>
  )
}

export default App